var searchData=
[
  ['pending_5flb15b_0',['PENDING_LB15B',['../linebreakdef_8h.html#af3ac615655bdce71b2b89179099e7043a6d86ee6e11da68207bcccb5f58bcf5b2',1,'linebreakdef.h']]],
  ['pending_5flb15c_1',['PENDING_LB15C',['../linebreakdef_8h.html#af3ac615655bdce71b2b89179099e7043a7acfc675de00feddc423fc8de7f89ca4',1,'linebreakdef.h']]],
  ['pending_5flb19a_2',['PENDING_LB19A',['../linebreakdef_8h.html#af3ac615655bdce71b2b89179099e7043ac16f7d5ca1ee5809678a5f6d1d6689fd',1,'linebreakdef.h']]],
  ['pending_5flb28a4_3',['PENDING_LB28A4',['../linebreakdef_8h.html#af3ac615655bdce71b2b89179099e7043aa7b0639f9ebc15e0f40cbdceaddf4aec',1,'linebreakdef.h']]],
  ['pending_5fnone_4',['PENDING_NONE',['../linebreakdef_8h.html#af3ac615655bdce71b2b89179099e7043ae0d143df348e9057f8ea564791cfd01a',1,'linebreakdef.h']]],
  ['prh_5fbrk_5',['PRH_BRK',['../linebreak_8c.html#a440c1a7abb9df5e3fc1d27b9a39e3a8da952ca85ab87da029497df2b4195df7d6',1,'linebreak.c']]]
];
