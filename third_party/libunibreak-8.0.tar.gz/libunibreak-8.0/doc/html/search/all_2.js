var searchData=
[
  ['clb30ari_0',['cLb30aRI',['../structLineBreakContext.html#a8d209260a846e51e00b67ce75f1874d7',1,'LineBreakContext']]],
  ['cmi_5fbrk_1',['CMI_BRK',['../linebreak_8c.html#a440c1a7abb9df5e3fc1d27b9a39e3a8dad5f5b78e1803b09e8c28a7a65a5f44fe',1,'linebreak.c']]],
  ['cmp_5fbrk_2',['CMP_BRK',['../linebreak_8c.html#a440c1a7abb9df5e3fc1d27b9a39e3a8da4951b690950173f20b284d041e56991f',1,'linebreak.c']]],
  ['cpendingorigbrk_3',['cPendingOrigBrk',['../structLineBreakContext.html#ad7a60ff8d57c430868f9102f90923d1a',1,'LineBreakContext']]]
];
