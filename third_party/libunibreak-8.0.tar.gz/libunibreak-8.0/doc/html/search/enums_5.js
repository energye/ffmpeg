var searchData=
[
  ['pendingrule_0',['PendingRule',['../linebreakdef_8h.html#af3ac615655bdce71b2b89179099e7043',1,'linebreakdef.h']]]
];
