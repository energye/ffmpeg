var searchData=
[
  ['get_5fnext_5fchar_5ft_0',['get_next_char_t',['../unibreakdef_8h.html#abaef21b29a783e73cbf236c1840e9061',1,'unibreakdef.h']]]
];
