var searchData=
[
  ['flangcjk_0',['fLangCjk',['../structLineBreakContext.html#a8f5e23199371cc6984427cea0cc29fd8',1,'LineBreakContext']]],
  ['flangstrict_1',['fLangStrict',['../structLineBreakContext.html#a87b4ebd05daf328e24c4a2c93b9edc44',1,'LineBreakContext']]],
  ['flb20awordinit_2',['fLb20aWordInit',['../structLineBreakContext.html#af6fbfcb5acfc06e08bc7dd6086398b2d',1,'LineBreakContext']]],
  ['flb21ahebrew_3',['fLb21aHebrew',['../structLineBreakContext.html#aae9c8c4e457a7c31683779d095532251',1,'LineBreakContext']]],
  ['flb25mark_4',['fLb25Mark',['../structLineBreakContext.html#a79ea3167ba1861d0b06fc31b575477c3',1,'LineBreakContext']]],
  ['flb28aakvi_5',['fLb28aAkVi',['../structLineBreakContext.html#a0d6ee14bd845fa8c22cd699cd41c6da3',1,'LineBreakContext']]],
  ['flb28aprevaksara_6',['fLb28aPrevAksara',['../structLineBreakContext.html#a29585ff86e548733b2790dc7af9df421',1,'LineBreakContext']]],
  ['flb8azwj_7',['fLb8aZwj',['../structLineBreakContext.html#a54024680e48e955ed6635f51a18b4366',1,'LineBreakContext']]],
  ['fpendingrevert_8',['fPendingRevert',['../structLineBreakContext.html#acb764e51e6a1042ca7027fa43b080697',1,'LineBreakContext']]],
  ['fprevea_9',['fPrevEA',['../structLineBreakContext.html#a881e39d33ab40a15c368d5e31054e1fc',1,'LineBreakContext']]],
  ['fprevpotentialemoji_10',['fPrevPotentialEmoji',['../structLineBreakContext.html#a29eb0661e59da51cd1e3d2288debb3d7',1,'LineBreakContext']]],
  ['fprevqupf_11',['fPrevQuPf',['../structLineBreakContext.html#a6850f604322b66f080dc4cb78def36ce',1,'LineBreakContext']]],
  ['fprevqupi_12',['fPrevQuPi',['../structLineBreakContext.html#af8c49faf516d7d015965871a3befe00b',1,'LineBreakContext']]],
  ['fqupiinitial_13',['fQuPiInitial',['../structLineBreakContext.html#ac55e89f6554157dccafd80be5ebfca18',1,'LineBreakContext']]],
  ['fquprevea_14',['fQuPrevEA',['../structLineBreakContext.html#a1fcc729d1a37a14e3884c5fc557af8bc',1,'LineBreakContext']]]
];
