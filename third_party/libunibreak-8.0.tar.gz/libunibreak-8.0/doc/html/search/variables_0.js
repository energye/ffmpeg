var searchData=
[
  ['clb30ari_0',['cLb30aRI',['../structLineBreakContext.html#a8d209260a846e51e00b67ce75f1874d7',1,'LineBreakContext']]],
  ['cpendingorigbrk_1',['cPendingOrigBrk',['../structLineBreakContext.html#ad7a60ff8d57c430868f9102f90923d1a',1,'LineBreakContext']]]
];
