var searchData=
[
  ['pending_5flb15b_0',['PENDING_LB15B',['../linebreakdef_8h.html#af3ac615655bdce71b2b89179099e7043a6d86ee6e11da68207bcccb5f58bcf5b2',1,'linebreakdef.h']]],
  ['pending_5flb15c_1',['PENDING_LB15C',['../linebreakdef_8h.html#af3ac615655bdce71b2b89179099e7043a7acfc675de00feddc423fc8de7f89ca4',1,'linebreakdef.h']]],
  ['pending_5flb19a_2',['PENDING_LB19A',['../linebreakdef_8h.html#af3ac615655bdce71b2b89179099e7043ac16f7d5ca1ee5809678a5f6d1d6689fd',1,'linebreakdef.h']]],
  ['pending_5flb28a4_3',['PENDING_LB28A4',['../linebreakdef_8h.html#af3ac615655bdce71b2b89179099e7043aa7b0639f9ebc15e0f40cbdceaddf4aec',1,'linebreakdef.h']]],
  ['pending_5fnone_4',['PENDING_NONE',['../linebreakdef_8h.html#af3ac615655bdce71b2b89179099e7043ae0d143df348e9057f8ea564791cfd01a',1,'linebreakdef.h']]],
  ['pendingrule_5',['PendingRule',['../linebreakdef_8h.html#af3ac615655bdce71b2b89179099e7043',1,'linebreakdef.h']]],
  ['poslast_6',['posLast',['../structLineBreakContext.html#a566c7f8b79771fdfb13d9e8a113e58ca',1,'LineBreakContext']]],
  ['poslb25fixup_7',['posLb25Fixup',['../structLineBreakContext.html#ad84aeb6a0bc0cdb86da3d4db45500d18',1,'LineBreakContext']]],
  ['pospending_8',['posPending',['../structLineBreakContext.html#a9d1f2e930ed841be270be7ce861df8ba',1,'LineBreakContext']]],
  ['prh_5fbrk_9',['PRH_BRK',['../linebreak_8c.html#a440c1a7abb9df5e3fc1d27b9a39e3a8da952ca85ab87da029497df2b4195df7d6',1,'linebreak.c']]],
  ['prop_10',['prop',['../structEastAsianWidthProperties.html#afb73ee1d73eac784ecb0105e6ff2030a',1,'EastAsianWidthProperties::prop'],['../structGraphemeBreakProperties.html#ac26f2959ac263c1e51df9cffb8b3ea98',1,'GraphemeBreakProperties::prop'],['../structIndicConjunctBreakProperties.html#a2567f00cafec6cd1bc388aeb6e2e8cdc',1,'IndicConjunctBreakProperties::prop'],['../structLineBreakProperties.html#a46d34ea3f514f8f082d92a441a6665ba',1,'LineBreakProperties::prop'],['../structWordBreakProperties.html#a30f8834130c9420301b1e94f66cbf4a0',1,'WordBreakProperties::prop']]]
];
